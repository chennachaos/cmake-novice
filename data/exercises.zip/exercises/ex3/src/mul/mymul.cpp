int mymul(int a, int b)
{
    return (a*b);
}
