

int myadd(int a, int b);
