int myadd(int a, int b)
{
    return (a+b);
}
