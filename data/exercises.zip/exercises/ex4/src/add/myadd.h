
#include "mpi.h"

int myadd(int a, int b);
