
#include "metis.h"

int mymul(int a, int b);
